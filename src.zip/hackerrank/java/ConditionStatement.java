package hackerrank.java;
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
public class ConditionStatement {

	public void checkWieard(int n){
		
		if(n<1){
			
		}
		else if(n > 1){
			if(n ==1){
				System.out.println("Weird");
			}
			else if((n%2) == 0){
				
				
			}else{
				System.out.println("Weird");
			}
		}
		else if(n > 100){
			
		}
		
		
	}
	public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();            
        String ans="";
        if(n%2==1){
          ans = "Weird";
        }
        else{
        
           if((n > 1) &&(n <= 4)){
        	   ans = "Not Weird";
           }
           else if((n > 5)&&(n <=20)){
        	   ans = "Weird";
           }
           else{
        	   if(n <= 0){
        		   ans = "invalid entry";
        	   }
        	   else{
        		   ans = "Not Weird";        		   
        	   }
           }
            
        }
        System.out.println(ans);
        
    }
}
