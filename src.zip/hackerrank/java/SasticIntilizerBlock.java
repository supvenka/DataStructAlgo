package hackerrank.java;

import java.util.Scanner;

public class SasticIntilizerBlock {

	private static int B;
	private static int H;
	private static boolean flag = false;
	private static Scanner input = new Scanner(System.in);
	static{
		
	}
	public static void main(String[] args) {
		
	}
}
