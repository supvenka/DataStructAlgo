package hackerrank.java.pre.kit.warmup;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class SockMarchant {

    // Complete the sockMerchant function below.
    static int sock_Merchant(int n, int[] ar) {
    	
    	int count = 0;
    	int val =0;
    	
    	Map mymap1 = new HashMap();
    	if((n < 0) ||(ar.length <= 0)){
    		return -1;
    	}
    	else{
    		for(int i = 0; i < ar.length; i++){
    			count = 0;
    			for(int j = 0; j<ar.length; j++){
    				if(ar[j]==ar[i]){
    					count++;
    				}
    			}
    			mymap1.put(ar[i], count);
    		}
    		System.out.println(mymap1);
    	}
    	Set s1 = mymap1.keySet();
    	Iterator it1 = s1.iterator();
    	while(it1.hasNext()){
    		int k = (int)mymap1.get(it1.next());
    		System.out.println(k);
    		if(k >1){
    			k = k / 2;
    			val = val +  k;
    		}
    		
    	}
    	System.out.println("final val::"+val);
		return val;
    }

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
       
    	int n = 9;
    	//int[] ar = {10,20,20,10,10,30,50,10,20};
    	int[] ar  = {6,5,2,3,5,2,2,1,1,5,1,3,3,3,5};
        int result = sock_Merchant(n, ar);
        System.out.println(result);

    }
}