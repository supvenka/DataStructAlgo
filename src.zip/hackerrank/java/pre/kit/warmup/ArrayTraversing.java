package hackerrank.java.pre.kit.warmup;

import java.util.*;

public class ArrayTraversing {

	
	static int test1(int n, int[] ar){
		int count = 0;
		Map<Integer, Integer> mymap1 = new HashMap();
		for(int i = 0; i < n; i++ ){
			count = 0;
			for(int j = i; j < n; j++){
				if(ar[i] == ar[j]){
					count++;
				}
			}
			if(i > 0){
				Set<Integer> s1 = mymap1.keySet();
				for(Integer k : s1){
					if(k!=ar[i]){
						mymap1.put(ar[i], count);
					}
				}
			}
			else{
				mymap1.put(ar[i], count);
			}
			
		}
		System.out.println("my map elements are : "+mymap1);
		
		
		
		return 1;
	}
	public static void main(String[] args) {
		int n = 9;
    	int[] ar = {10,20,20,10,10,30,50,10,20};
        int result = test1(n, ar);
        System.out.println(result);
	}
	
	
}
