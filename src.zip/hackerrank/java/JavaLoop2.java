package hackerrank.java;

import java.util.Scanner;

public class JavaLoop2 {

    public static void main(String []argh){
        Scanner in = new Scanner(System.in);
        int t=in.nextInt();
        int count = 0;
        int power = 1;   
        int temp = 0;
        for(int i=0;i<t;i++){
        	
            int a = in.nextInt();
            int b = in.nextInt();
            int n = in.nextInt();
        
            if(a>=0 && b >=0 && n >=1){
            for(int j = 1; j<=n;j++)
            {
            	temp = 0;
            	int k =0;
            	
            	for(; k<j; k++)
            	{
            		
            		if(k == 0){
            			power = 1;
            		}
            		else{
            			power =  power * 2;
            		}
            		temp = temp + (power * b);
            		
            	}
            	count = a + temp;
            	System.out.print(count+" ");
            	
            }
            }
            else{
            	System.out.println("invalid input element");
            }
         
        }
        in.close();
    }
}
