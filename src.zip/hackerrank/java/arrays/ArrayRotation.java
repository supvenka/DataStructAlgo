package hackerrank.java.arrays;

import java.util.Arrays;

public class ArrayRotation {

	public static void main(String[] args) {
		
		int[] arr = {1,2,3,4,5};
		arrayRotation(arr, 1);
	}
	public static void arrayRotation(int[] arr, int disp){
		int temp;
		for(int i=0; i < disp; i++){
			
			temp = arr[0];
			for(int j = 0 ;j< (arr.length -1); j++)
			{
				arr[j] = arr[j+1];
			}
			arr[(arr.length -1)] = temp;
			
		}
		
		System.out.println(Arrays.toString(arr));
	}
}
