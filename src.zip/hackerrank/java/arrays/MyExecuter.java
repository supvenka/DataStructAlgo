package hackerrank.java.arrays;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyExecuter {

public static void main(String[] args) {
	
	ExecutorService executor;
	
	executor = Executors.newFixedThreadPool(10);
	Long[] arr = { 0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
	executor.submit(new MyTask(arr,10L,1,10,3));
	executor.submit(new MyTask(arr,10L,2,6,7));
	executor.submit(new MyTask(arr,10L,3,9,11));
}	

}

class MyTask implements Runnable{
	
	Long[] arr;
	Long n;
	int start, end, value;
	public MyTask(Long[] arr, Long n, int start,int end, int value) {
		this.arr = arr;
		this.n = n;
		this.start = start;
		this.end = end;
		this.value = value;
	}
	public void run(){
		long presentValue =0;
		long temp = Long.MIN_VALUE;
		for(int i = 0, d = arr.length; i<d; i++){
			if((i >= start) && (i <=end)){
				presentValue = arr[i];
				presentValue = presentValue + value;
				arr[i] = presentValue;
				if(presentValue > temp){
					temp = presentValue; 
				}
			
			}
			
			i++;
		}
		System.out.println("tempValue is::"+temp);
	}
}

