package hackerrank.java.arrays;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ArrayManipulation {

	static ExecutorService executor = Executors.newFixedThreadPool(10);
	
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		System.out.println(arrayManipulation(5, new int[][] { { 2, 5, 100 },
				{ 1, 3, 200 }, { 4, 5, 100 } }));
	}

	static Long arrayManipulation(int n, int[][] queries) throws InterruptedException, ExecutionException {
		
		int j = 0;
		Long myval = Long.MIN_VALUE;
		Future<Long> myfuture;
		long arr[] = new long[n];
		for (int i = 0, d = queries.length; i < d; i++) {
			j = 0;
			int start = queries[i][j];
			int end = queries[i][j + 1];
			int value = queries[i][j + 2];
			myfuture = executor.submit(new MaxSum(arr, start, end, value, myval));
			myval = myfuture.get();
		}
		return myval;

	}


}

class MaxSum implements Callable{
	
	long[] arr;
	int start, end;
	long value, prevtempValue;
	
	public MaxSum(long[] arr, int start, int end, long value, long prevtempValue) {
		
		this.arr = arr;
		this.start = start;
		this.end = end;
		this.value = value;
		this.prevtempValue = prevtempValue;
	}
	Long addelements() {

		Long presentValue;
		long temp = prevtempValue;
		int i = 1;
		for (int j = 0; j < arr.length; j++) {
			if ((i >= start) && (i <= end)) {
				presentValue = arr[j];
				presentValue = presentValue + value;
				arr[j] = presentValue;
				if (presentValue > temp) {
					temp = presentValue;
				}

			}

			i++;
		}

		return temp;
	}

	@Override
	public Long call() throws Exception {
		
		return addelements();
	}
}