package hackerrank.java.arrays;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.RecursiveAction;

public class MyRecursiveAction extends RecursiveAction {

    private long[] arr;

    public MyRecursiveAction(long[] arr) {
        this.arr = arr;
    }

    @Override
    protected void compute() {

        //if work is above threshold, break tasks up into smaller tasks
        if(this.arr.length > 1000) {
            System.out.println("Splitting workLoad : " + this.arr);

            List<MyRecursiveAction> subtasks =
                new ArrayList<MyRecursiveAction>();

            subtasks.addAll(createSubtasks());

            for(RecursiveAction subtask : subtasks){
                subtask.fork();
            }

        } else {
            System.out.println("Doing workLoad myself: " + this.arr);
        }
    }

    private List<MyRecursiveAction> createSubtasks() {
        List<MyRecursiveAction> subtasks =
            new ArrayList<MyRecursiveAction>();

        MyRecursiveAction subtask1 = new MyRecursiveAction(this.arr);
        MyRecursiveAction subtask2 = new MyRecursiveAction(this.arr);

        subtasks.add(subtask1);
        subtasks.add(subtask2);

        return subtasks;
    }

}