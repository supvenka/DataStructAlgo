package hackerrank.java.arrays;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.RecursiveTask;

public class CopyOfArrayManipulation2 {

	static ExecutorService executor = Executors.newFixedThreadPool(10);
	
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		System.out.println(arrayManipulation(5, new int[][] { { 2, 5, 100 },
				{ 1, 3, 200 }, { 4, 5, 100 } }));
	}

	static Long arrayManipulation(int n, int[][] queries) throws InterruptedException, ExecutionException {

		int nThreads = Runtime.getRuntime().availableProcessors();
		ForkJoinPool forkJoinPool = new ForkJoinPool(nThreads);
		

		int j = 0;
		Long myval = Long.MIN_VALUE;
		long arr[] = new long[n];
		for (int i = 0, d = queries.length; i < d; i++) {
			j = 0;
			int start = queries[i][j];
			int end = queries[i][j + 1];
			int value = queries[i][j + 2];
			myval = forkJoinPool.invoke(new MaxSum1(arr, start, end, value, myval));
		}
		return myval;

	}


}

class MaxSum1 extends RecursiveTask<Long>{
	
	long[] arr;
	int start, end;
	long value, prevtempValue;
	
	public MaxSum1(long[] arr, int start, int end, long value, long prevtempValue) {
		
		this.arr = arr;
		this.start = start;
		this.end = end;
		this.value = value;
		this.prevtempValue = prevtempValue;
	}
	Long addelements() {

		Long presentValue;
		long temp = prevtempValue;
		int i = 1;
		 for(int j =0, d = arr.length; j<d; j++){
			if ((i >= start) && (i <= end)) {
				presentValue = arr[j];
				presentValue = presentValue + value;
				arr[j] = presentValue;
				if (presentValue > temp) {
					temp = presentValue;
				}

			}

			i++;
		
		 }
		return temp;
	}

	
	
	@Override
	protected Long compute() {
		// TODO Auto-generated method stub
		return addelements();
	}
}