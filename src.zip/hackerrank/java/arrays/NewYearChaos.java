package hackerrank.java.arrays;

public class NewYearChaos {

	public static void main(String[] args) {
		int[] arr = {1,2,3,4,5};
		System.out.println(chaosFinder(arr));
	}
	
	static String chaosFinder(int[ ]q){
		Integer count = 0;
		for(int i = 1, d = (q.length)-1 ; i<=d ; i++){
			if((i+2)== q[i]){
				count++;
			}
			else if((i+1)== q[i]){
				count++;
			}
		}
		if(count >0){
			return count.toString();
		}
		else{
			return "Too Chaiotic";
		}
	}
}
