package hackerrank.java.arrays;

public class StringReversal {

	public static String[] reverseArray(String[] arr){


		String temp = null;
		for(int i = 0, n = arr.length; (i < n/2); i++){

			temp = arr[i];
			arr[i] = arr[n -i -1];
			arr[n -i -1] = temp;

		}
		return arr;

		}
	
	public static void main(String[] args) {
		String[] arr = {"a","b","c","d"};
		reverseArray(arr);
	}
	
	
}
