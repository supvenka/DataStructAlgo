package hackerrank.java;

import java.util.*;
import java.security.*;

import com.sun.org.apache.bcel.internal.generic.INSTANCEOF;

public class JavaIntToString {

	public static void main(String[] args) {
		
		//DoNotTerminate.forbidExit();

		  try {
		   Scanner in = new Scanner(System.in);
		   int n = in .nextInt();
		   in.close();
		   
		   String s= ""+n;
		   
		   if(s!= null){
			   if(s instanceof String){
				   System.out.println("Good Job");
			   }
		   }
		   else{
			   System.out.println("Wrong answer");
		   }

		   //Write your code here
		  }catch(Exception e){e.printStackTrace();}
		  
	}
}
