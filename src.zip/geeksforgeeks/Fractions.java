package geeksforgeeks;

import java.math.BigDecimal;
import java.util.Scanner;

public class Fractions {

	public static void main(String[] args) {
		Fractions f = new Fractions();
		int[] number = new int[2];
		int[] decimal = new int[2];
		int[] fractionValue = new int[2];
		if(args.length == 0){
			assert args.length == 0 : "error occured";
		}
		else if(Integer.parseInt(args[0]) == 1){
			number[0] = Integer.parseInt(args[1]);
			number[1] = Integer.parseInt(args[3]);
			
			decimal[0] = Integer.parseInt(args[2]);
			decimal[1] = Integer.parseInt(args[4]);
			
			if((number.length == 2) && (decimal.length == 2)){
				fractionValue = f.addFraction(number, decimal);
				
				
			}
		}
		else{
			assert Integer.parseInt(args[0]) > 1 : "this program does not support as of now";
		}
		double calValue = fractionValue[0]/fractionValue[1];
		System.out.print(fractionValue[0] + "/" + fractionValue[1] +"= " +new BigDecimal(calValue).toString());

	}

	public int[] addFraction(int[] number, int[] decimal) {
		
		int[] factValue = new int[2];
		try {
			int numerator1 = number[0] * decimal[1];
			int denominator1 = decimal[0] * decimal[1];
			
			int numerator2 = number[1] * decimal[0];
			int denominator2 = decimal[1] * decimal[0];
			
			factValue[0] = numerator1 + numerator2;
			if(denominator2 == denominator1){
				factValue[1] = denominator1;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			return factValue;
		}
		
	}
}
