package arrays;

import java.util.Arrays;

public class ArrayRotationLogic {

	public static void main(String[] args) {
		ArrayRotationLogic arl1 = new ArrayRotationLogic();
		String[] abcd = arl1.rotateStingArray(new String[]{"a","b","c","d","e"},3);
		System.out.println(Arrays.toString(abcd));
		
	}
	
	public String[] rotateStingArray(String[] rotate, int displacement ){
		
		String[] rotatedString = rotate;
		if(rotate.length <=0){
		return rotatedString;
		}
		else{
			if(rotatedString.length == 1){
			return rotatedString;
			}
			else{
				if(displacement<=0){
					return rotatedString;
				}
				else{
					for(int i = 0; i < displacement; i++ )
						rotatedString = rotateOneElementInArray(rotate);
				return rotatedString;
				}
			}
		}
	}
	
	private String[] rotateOneElementInArray(String[] rotatedString){
		
		
		String temp = rotatedString[0];
		for(int i =0; i<(rotatedString.length)-1; i++){
			if((rotatedString.length)-1 == i){
				rotatedString[i] = rotatedString[i];
			}else{
				rotatedString[i] = rotatedString[i+1];
			}
		}
		rotatedString[(rotatedString.length)-1] = temp;
		return rotatedString;
		
	}
}
