package arrays;

public class StringRotation {

	public static void main(String[] args) {
		
		StringRotation sr1 = new StringRotation();
		String[] str1 = {"aaa","bbb","ccc","ddd","eee","fff"};
		str1 = sr1.rotate(str1,2, 5);
		sr1.printString(str1);
	}
	
	private String[] rotate(String[] array1, int d, int n){
		String temp = "";
		String temp2 = "";
		int j = d;
		
		for(int i = 0; i < d; i++){
			leftRotatebyOne(array1,n);
		}
		return array1;
		//printString(array1);	
	}
	public void printString(String[] array1){
		for(int i= 0 ; i < array1.length; i++){
			System.out.println(array1[i]);
		}
	}
	
	private void leftRotatebyOne(String arr[], int n) 
    {
        int i;
        String temp;
        temp = arr[0];
        for (i = 0; i < n ; i++)
            arr[i] = arr[i + 1];
        arr[i] = temp;
    }
}
