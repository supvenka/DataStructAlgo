package arrays;

public class ReversalAlgoritham {

	public static void main(String[] args) {
		ReversalAlgoritham ra1 = new ReversalAlgoritham();
		String[] str1 = {"aaa","bbb","ccc","ddd","eee","fff"};
		ra1.rotate(str1, 2, 5);
	}
	
	public void rotate(String[] arr1,int d, int n){
		
		reverse(arr1,0,d);
		reverse(arr1,d+1,n);
		reverse(arr1,0,n);
		for(int i = 0; i < arr1.length; i++){
			System.out.println(arr1[i]);
		}
	}
	
	private void reverse(String[] arr1, int start, int end){
		int j = 0;
		String temp;
		for(int i = end; i > start/2; i--){
			temp = arr1[i];
			arr1[i] = arr1[j];
			arr1[j] = temp;
		}
			
	}
}
