package arrays;

public class RotatedArrayBinarySearch {

	public static void main(String[] args) {
		RotatedArrayBinarySearch rotatedbinarysearch = new RotatedArrayBinarySearch();
		/*int Elementfound = rotatedbinarysearch.linearSearch(new int[] { 5, 6,
				7, 8, 9, 10, 1, 2, 3 }, 3);
		if (Elementfound == -1) {
			System.out.println("Element not found in the array");
		} else {
			System.out.println("Elementfound at location:: " + Elementfound);
		}*/
		
		int Elementfound = rotatedbinarysearch.binarySearch(new int[] { 5, 6, 7, 8, 9, 10, 1, 2, 3 }, 9);
		if (Elementfound == -1) {
			System.out.println("Element not found in the array");
		} else {
			System.out.println("Elementfound at location:: " + Elementfound);
		}

	}

	public int linearSearch(int[] a, int searchElement) {
		int elementfound = -1;
		for (int i = 0; i < a.length; i++) {
			if (a[i] == searchElement) {
				elementfound = i;
			}
		}
		return elementfound;
	}
	
	public int binarySearch(int[] a, int searchElement) {
		int elementfound = -1;
		int povit = (a.length)/2;
		int firstelement = a[0];
		int lastelement = a[a.length -1];
		int k = (a.length-1);
		int start = -1;
		int end = -1;
		while(k <= 0){
			
			if(a[povit] > firstelement ){
				povit++;
				k--;
			}
			else if(a[povit] < firstelement){
				end = povit - 1;
				start = povit;
				povit = 0;
				k = (a.length-1);
				if(searchElement >a[end]){
					elementfound = -1;
					return elementfound;
				}
				else if((searchElement >=a[start])&&(searchElement <=a[end]) ){
					if(a[povit]>=searchElement){
						if(a[povit] == searchElement){
							elementfound = povit;
						} else{
						povit = start;k--;
						}
					}
					else if(a[povit]<=searchElement){
						if(a[povit] == searchElement){
							elementfound = povit;
						} else{
							povit = end;k--;
						}
						
					}
				}
				
				else{
					elementfound = -1;
					System.out.println("element not found");
				}
			}
			
			
		}
		return elementfound;
	}
}
