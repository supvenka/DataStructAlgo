package searching;

public class LSearch {

	public static void main(String[] args) {
		LSearch ls = new LSearch();
	}
	
	public int linearSearch(int[] a, int searchelem, int index){
		
		
			if(a[index] == searchelem){
				return index;
		    }
			else{
				if(index >= a.length){
					linearSearch(a,searchelem,index+1);
				}
				else{
					return -1;
				}	
			}
		
		
	}
}
