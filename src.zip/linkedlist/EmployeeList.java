package linkedlist;

public class EmployeeList {

	Employee head;
	
	static class Employee{
		int empid;
		Employee nextempref;
		Employee(int id){empid = id;nextempref = null;}
	}
}