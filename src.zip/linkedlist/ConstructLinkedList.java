package linkedlist;

import linkedlist.EmployeeList.Employee;

public class ConstructLinkedList {

	
	
	private EmployeeList employees = new EmployeeList();
	
	
	
	public void constructALinkedList(int numberOfNodes){
		employees.head = new Employee(1);
		Employee previousEmp = employees.head;
		for(int i = 2; i<= numberOfNodes; i++){
			
			Employee emp = new Employee(i);
			previousEmp.nextempref = emp;
			previousEmp = emp;
		}
		
		
	}
	public void printEmpList(){
		Employee currectEmp = employees.head;
		while(currectEmp != null){
			System.out.println(currectEmp.empid);
			currectEmp = currectEmp.nextempref;
		}
	}
	public static void main(String[] args) {
		ConstructLinkedList constructAList = new ConstructLinkedList();
		constructAList.constructALinkedList(5);
		constructAList.printEmpList();
		
	}
}
