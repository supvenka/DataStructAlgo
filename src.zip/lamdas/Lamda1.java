package lamdas;
import java.util.Arrays;
import java.util.List;


public class Lamda1 {

	public static void main(String[] args) {
		List<Integer> intgrs = Arrays.asList(1,2,3,4,5);
		
		intgrs.forEach(x->System.out.println(x));
		
	}
}

