package lamdas;


interface PasswordEncoder{
	public String encode(String password, String salt);
}


public class Main1{
	
	public PasswordEncoder makeBadEncoder(){
		return (password,salt) -> password.toUpperCase();
	}
	
	public void doSomeThing(PasswordEncoder encoder){
		
		String salted = encoder.encode("abcd", "123");
		System.out.println(salted);
	}
	
	public static void main(String[] args) {
		Main1 m1 = new Main1();
		PasswordEncoder encoder = m1.makeBadEncoder();
		m1.doSomeThing(encoder);
	}
}