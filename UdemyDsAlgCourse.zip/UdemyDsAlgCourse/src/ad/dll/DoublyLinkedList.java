package ad.dll;

public class DoublyLinkedList {

	private Node first;
	private Node last;

	public DoublyLinkedList() {
		first = null;
		last = null;
	}

	public boolean isEmpty() {
		return (first == null);
	}

	public void insertFirst(int data) {

		Node newNode = new Node(data);
		if (isEmpty()) {
			last = newNode;
		} else {
			first.prev = newNode;
			newNode.next = first;
		}
		first = newNode;
	}

	public void insertLast(int data) {
		Node newNode = new Node(data);
		if (last != null) {
			last.next = newNode;
			newNode.prev = last;
		} else {
			first = newNode;
		}
		last = newNode;
	}

	public Node deleteFirst() {
		Node temp = first;
		if (last != null && first != null) {
			if (first.next == null) {
				last = null;
			} else {
				first.next.prev = null;
			}
			first = first.next;
		}
		return temp;
	}

	public Node deleteLast() {
		Node temp = last;

		if (last != null && first != null) {
			if (last.prev == null) {
				first = null;
			} else {
				last.prev.next = null;
			}
			last = last.prev;
		}
		return temp;
	}

	public boolean insertAfter(int key, int data) {
		Node current = first;
		Node newNode = new Node(data);
		while (current != null) {
			if(current == last && current.data==key){
				insertLast(data);
				return true;
			}
			if (current.data == key) {
				newNode.next = current.next;
				current.next.prev = newNode;
				newNode.prev = current;
				current.next = newNode;
				return true;
			} else {
				current = current.next;
			}
		}
		return false;
	}
	
	public boolean insertBefore(int key, int data) {
		Node current = first;
		Node newNode = new Node(data);
		while (current != null) {
			if(current == first && current.data==key){
				insertFirst(data);
				return true;
			}
			if (current.data == key) {
				current.prev.next=newNode;
				newNode.next=current;
				newNode.prev=current.prev;
				current.prev=newNode;
				return true;
			} else {
				current = current.next;
			}
		}
		return false;
	}
	
	public boolean deleteKeyNode(int key){
		Node current = first;
		while (current != null) {
			if(current==last && current.data==key){
				deleteLast();
				return true;
			}
			if(current==first && current.data==key){
				deleteFirst();
				return true;
			}
			if (current.data == key) {
				current.prev.next=current.next;
				current.next.prev=current.prev;
				return true;
			} else {
				current = current.next;
			}
		}
		return false;
	}

	public void display() {
		Node current = first;
		System.out.println("First -- > Last");
		while (current != null) {
			current.displayNode();
			current = current.next;
		}
	}
}
