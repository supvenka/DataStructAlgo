package ad.dll;

public class Node {

	Node next = null;
    Node prev = null;
	int data;
	
	public Node(int data){
		this.data = data;
	}
	
	public void displayNode(){
		System.out.println("{ "+ data +"}");
	}
	
}
