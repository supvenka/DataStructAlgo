package ad.dll;

public class TestDoublyLinkedList {

	public static void main(String args[]){
		
		DoublyLinkedList dll = new DoublyLinkedList();
		
		dll.insertFirst(10);
		dll.insertLast(20);
		dll.insertFirst(15);
		dll.insertLast(18);
		dll.display();
		dll.deleteFirst();
		dll.display();
		dll.deleteLast();
		dll.display();
		dll.deleteLast();
		dll.display();
		dll.deleteFirst();
		dll.display();
		dll.deleteLast();
		dll.display();
		dll.deleteFirst();
		dll.display();
		dll.insertFirst(10);
		dll.insertLast(20);
		dll.insertFirst(15);
		dll.insertLast(18);
		dll.display();
		dll.insertAfter(20, 33);
		dll.display();
		
		dll.insertAfter(10, 34);
		dll.display();
		dll.insertAfter(18, 35);
		dll.display();
		dll.insertAfter(15, 36);
		dll.display();
		
		dll.insertBefore(10, 30);
		dll.display();
		dll.insertBefore(18, 30);
		dll.display();
		dll.insertBefore(15, 30);
		dll.display();
		
		dll.deleteKeyNode(30);
		dll.display();
		
		dll.deleteKeyNode(18);
		dll.display();
		
		
		dll.deleteKeyNode(35);
		dll.display();
		
		
	}
}
