package ad.graph;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	/*	Graph graph = new Graph(5);
		graph.addEdge(0, 1);
		graph.addEdge(0, 2);
		graph.addEdge(1, 2);
		graph.addEdge(1, 4);
		graph.addEdge(2, 3);
		graph.addEdge(3, 5);
		graph.addEdge(4, 2);
	    
		Object[] obj = graph.adj(0);
		for(int i=0;i<obj.length;i++){
			System.out.println(obj[i]);
		}*/
		
		BetterGraph btr = new BetterGraph(5, true);
		
        btr.addVertex("Nagawara");
        btr.addVertex("Hebbal");
        btr.addVertex("MGRoad");
        btr.addVertex("Hennur");
        btr.addVertex("Thanisandhra");
        
        btr.addEdge("Nagawara", "Hebbal");
        btr.addEdge("Nagawara", "Thanisandhra");
        btr.addEdge("Hebbal", "MGRoad");
        btr.addEdge("Thanisandhra", "Hebbal");    
        btr.addEdge("MGRoad", "Hennur");
        btr.addEdge("Hennur", "Nagawara");
        btr.addEdge("Hennur", "Thanisandhra");
        
        
        btr.print();
	}
	
	

}
