package ad.graph;

import java.lang.reflect.Array;

import adt.ll.LinkedList;

public class BetterGraph {

	Vertex[] arrayOfLists;
	int indexCounter ;
	boolean undirected = true;
	
	class Node {
		public int vertexIndex;
		public Node next;
		Node(int vertexIndex,Node node){
			this.vertexIndex = vertexIndex;
			next = node;
		}
	}
	
	class Vertex{
		
		String name;
		Node adjList;
		
		Vertex(String name,Node adjList){
			this.name = name;
			this.adjList =adjList;
		}
		
	}
	
	public BetterGraph(int size,boolean directed){
		if(directed){
			undirected = false;
		}
		arrayOfLists = new Vertex[size];
	}
	
	
	public void addVertex(String name){
		arrayOfLists[indexCounter] = new Vertex(name, null);
		indexCounter++;
	}
	
	public void addEdge(String src, String dest){
		int vIdx1 = indexForName(src);
		int vIdx2 = indexForName(dest);
		
		arrayOfLists[vIdx1].adjList = new Node(vIdx2,arrayOfLists[vIdx1].adjList);
		if(undirected){
			arrayOfLists[vIdx2].adjList = new Node(vIdx1,arrayOfLists[vIdx2].adjList);
		}
		
	}


	private int indexForName(String src) {
		// TODO Auto-generated method stub
		for(int i=0;i<arrayOfLists.length;i++){
			if(arrayOfLists[i].name.equals(src))return i;
			
		}
		return -1;
	}
	
	public void print(){
		for(int i=0;i<arrayOfLists.length;i++){
			System.out.print(arrayOfLists[i].name);
			for(Node node=arrayOfLists[i].adjList;node!=null;node =node.next){
				System.out.print("-->"+arrayOfLists[node.vertexIndex].name);
			}
			System.out.println();
		}
		
	}
}
