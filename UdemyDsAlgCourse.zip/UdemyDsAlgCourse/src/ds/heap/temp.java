package ds.heap;

public class temp {
	// This is a place holder. The code for this data structure will be added shortly
}
