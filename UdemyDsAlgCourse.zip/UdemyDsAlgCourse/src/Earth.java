
public class Earth {
	
	public static void main(String args[]){
		Human hum1 = new Human("Pavan", 23, "red",100);
		Human hum2 = new Human("Sushma", 21, "blue",110);
		hum1.speak();
		hum2.speak();
		
	}

}
