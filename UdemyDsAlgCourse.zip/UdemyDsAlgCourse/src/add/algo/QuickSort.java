package add.algo;

public class QuickSort {

	static int a[] = new int[] { 2, 4, 9, 8, 8, 99, 7, 0, 1, 3, 5, 6 };

	public static int[] sort(int[] a, int p, int r) {
		int q;
		if (p < r) {
			q = partition(a, p, r);
			sort(a, p, q - 1);
			sort(a, q + 1, r);
		} else {
			return a;
		}
		return a;

	}

	private static int partition(int[] a, int p, int r) {
		// TODO Auto-generated method stub
		int pivot = a[r];
		int i = p - 1;
		int j = p;
		int temp;
		while (j < r) {
			if (a[j] < pivot) {
				i++;
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
			j++;
		}

		i++;
		temp = a[i];
		a[i] = a[r];
		a[r] = temp;
		display(a);
		return i;
	}

	public static void display(int[] arr) {
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println("---------------------");
	}

	public static void main(String args[]) {
		sort(a, 0, 11);
		display(a);
	}
}
