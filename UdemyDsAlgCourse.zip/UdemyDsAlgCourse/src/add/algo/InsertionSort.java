package add.algo;

public class InsertionSort {

	public static int[] sort(int[] a) {
		int temp;
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < i; j++) {
				if (a[j] > a[i]) {
					temp = a[j];
					a[j] = a[i];
					a[i] = temp;
				}
			}

		}
		display(a);
		return a;
	}

	public static int[] sortNew(int[] a) {
		for (int i = 1; i < a.length; i++) {
			int j = i - 1;
			int element = a[i];
			while (j >= 0 && a[j] > element) {
				a[j + 1] = a[j];
				j--;
				display(a);
			}

			a[j + 1] = element;
			display(a);
		}
		display(a);
		return a;
	}

	public static int[] recursiveInsertionSort(int[] a, int i) {

		if (i >= a.length) {
			display(a);
			return a;
		} else {
			System.out.println(i);
			int j = i - 1;
			int element = a[i];
			while (j >= 0 && a[j] > element) {
				a[j + 1] = a[j];
				j--;
				display(a);
			}
			a[j + 1] = element;
			recursiveInsertionSort(a, ++i);
		}
		System.out.println("Returning i value"+i);
		display(a);
		return a;

	}

	static int[] insertionSortRecursive(int arr[], int n) {
		// Base case
		if (n <= 1)
			return arr;

		// Sort first n-1 elements
		insertionSortRecursive(arr, n - 1);

		// Insert last element at its correct position
		// in sorted array.
		int last = arr[n - 1];
		int j = n - 2;

		/*
		 * Move elements of arr[0..i-1], that are greater than key, to one
		 * position ahead of their current position
		 */
		while (j >= 0 && arr[j] > last) {
			arr[j + 1] = arr[j];
			j--;
		}
		arr[j + 1] = last;
		return arr;
	}

	public static void display(int[] arr) {
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println("---------------------");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// sort(new int[] { 2, 4, 1, 3, 5, 6, 9, 8, 7, 0 });

		recursiveInsertionSort(new int[] { 2, 4, 1, 3, 5, 6, 9, 8, 8, 99, 7, 0 }, 1);

		// display(insertionSortRecursive(new int[] { 2, 4, 1, 3, 5, 6, 9, 8, 8,
		// 99, 7, 0 },(new int[] { 2, 4, 1, 3, 5, 6, 9, 8, 8, 99, 7, 0 }).length
		// ));
	}
}
