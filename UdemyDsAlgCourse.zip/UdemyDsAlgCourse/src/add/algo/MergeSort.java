package add.algo;

public class MergeSort {

	static int a[] = new int[] { 2, 4, 1, 3, 5, 6, 9, 8, 8, 99, 7, 0 };

	public static int[] mergeSort(int[] a, int p, int r) {
		int q;
		if (p < r) {
			q = (p + r) / 2;
			mergeSort(a, p, q);
			mergeSort(a, q + 1, r);
			merge(a, p, q, r);
		//	display(a);
		} else {
			return a;
		}
		return a;
	}

	private static void merge(int[] a, int p, int q, int r) {
		// TODO Auto-generated method stub

		int temp[] = new int[r - p + 1];
		int leftSlot = p, rightSlot = q + 1;
		int k = 0;
		while (leftSlot <= q && rightSlot <= r) {
			if (a[leftSlot] < a[rightSlot]) {
				temp[k] = a[leftSlot];
				leftSlot++;
			} else {
				temp[k] = a[rightSlot];
				rightSlot++;
			}
			k++;
		}

		if (leftSlot <= q) {
			while (leftSlot <= q) {
				temp[k] = a[leftSlot];
				leftSlot++;
				k++;
			}
		} else {
			while (rightSlot <= r) {
				temp[k] = a[rightSlot];
				rightSlot++;
				k++;
			}
		}

		for (int i = 0; i < temp.length; i++) {
			a[p + i] = temp[i];
		}

	}

	public static void display(int[] arr) {
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println("---------------------");
	}

	public static void main(String args[]) {
		mergeSort(a, 0, 11);
		display(a);
	}
}
