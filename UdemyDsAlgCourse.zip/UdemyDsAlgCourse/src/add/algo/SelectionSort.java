package add.algo;

public class SelectionSort {

	public static int[] sort(int[] a) {

		int temp;
		display(a);
		for (int i = 0; i < a.length; i++) {
			int min = a[i];
			for (int j = i + 1; j < a.length; j++) {
				if (a[j] < min) {
					temp = a[j];
					a[j] = min;
					min = temp;
				}
			}
			a[i]=min;
			display(a);
		}
		return a;
	}

	public static void display(int[] arr){
		for(int i=0;i<arr.length;i++){
			 System.out.print(arr[i]+" ");
		 }
		System.out.println("---------------------");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = sort(new int[]{2,4,1,3,5,6,9,8,7,0});
	}

}
