package add.bst;

public class BinarySearchTree {

	Node root;

	public BinarySearchTree() {
		root = null;
	}

	public void insertNode(int data) {

		Node n = new Node(data);
		if (root == null) {
			root = n;
		} else {

			Node parIns = root;
			Node insParent = parIns;

			while (parIns != null) {
				insParent = parIns;
				if (parIns.data > data) {
					parIns = parIns.getLeft();
				} else {
					parIns = parIns.getRight();
				}
			}
			if (insParent.data > data)
				insParent.setLeft(n);
			else
				insParent.setRight(n);

		}

	}
	
	
	public void deleteNode(int data) {

		Node n = new Node(data);
		if (root == null) {
			root = n;
		} else {

			Node parIns = root;
			Node insParent = parIns;

			while (parIns != null) {
				insParent = parIns;
				if(insParent.getLeft().data == data)
				{
				   if(insParent.getLeft().getLeft()!=null){
					   insParent.setLeft(insParent.getLeft().getLeft());
				   }	
					
				}
				if (parIns.data > data) {
					parIns = parIns.getLeft();
				} else {
					parIns = parIns.getRight();
				}
			}
			if (insParent.data > data)
				insParent.setLeft(n);
			else
				insParent.setRight(n);

		}

	}
	
	

	public Node getRoot() {
		return root;
	}

	public void inOrderTraversal(Node n) {

		if (n != null) {
			inOrderTraversal(n.getLeft());
			n.print();
			inOrderTraversal(n.getRight());
		}

	}

}
