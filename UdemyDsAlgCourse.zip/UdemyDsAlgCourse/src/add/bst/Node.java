package add.bst;

public class Node {

	private Node left;
	private Node right;
	public int data;

	public Node(int data) {
		this.data = data;
	}

	public void setLeft(Node n) {
		left = n;
	}

	public Node getLeft() {
		return left;
	}
	
	public void setRight(Node n) {
		right= n;
	}

	public Node getRight() {
		return right;
	}
	
	public void print(){
		System.out.println("Node data:"+data);
	}

}
