package add.bst;

public class BstApp {
	
	public static void main(String args[]){
		
		BinarySearchTree bst = new BinarySearchTree();
		bst.insertNode(7);
		bst.insertNode(4);
		bst.insertNode(6);
		bst.insertNode(9);
		bst.insertNode(3);
		bst.insertNode(1);
		bst.insertNode(2);
		
		System.out.println("Root value:"+bst.getRoot().data);
		bst.inOrderTraversal(bst.getRoot());
		
	}

}
