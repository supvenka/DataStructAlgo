package algo.insertionsort;

public class App {

	public static void main(String[] args) {
		// int myArray[] = insertionSort(new int[] {9,8,99,110,8,87,637,
		// 8,3,13,87,12,99});

		System.out.println(median(new int[] { 1,2,3,4 }));

		System.out.println(median(new int[] { 1,3,4}));
		
		System.out.println(median(new int[] {88}));
		
		
		System.out.println(median(new int[] { 1,3,4,9,10,12}));

	}

	public static int[] insertionSort(int[] a) {
		int element, j;
		for (int i = 1; i < a.length; i++) {
			element = a[i];
			j = i - 1;
			while (j >= 0 && a[j] > element) {
				a[j + 1] = a[j];
				j--;
			}
			a[j + 1] = element;
			System.out.println("Element :" + element);
			display(a);
		}
		return a;
	}

	public static float median(int[] a) {
		//System.out.println(a.length/2);
		if(a.length==1){
			return a[0];
		}
		if (a.length%2 == 0) {
			return ((float)a[(a.length/2 -1)] + a[a.length/2])/2;
		} else {
			return a[a.length/2];
		}

	}

	public static void display(int[] a) {
		System.out.println();
		System.out.print("[");
		for (int i = 0; i < a.length; i++) {
			System.out.print(" " + a[i] + " ");
		}

		System.out.print("]");
		System.out.println();
	}
}
