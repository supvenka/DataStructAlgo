package adt.ll;

public class LinkedList {

	private Node first;
	private Node last;

	public boolean isEmpty() {

		return (first == null);
	}

	public void insertFirst(int data) {
		
		Node node = new Node(data);
		node.next = first;
		if(isEmpty()){
			last = node;
		}
		first = node;
	}

	public Node deleteFromFirst() {		
		Node temp =first;
		first = first.next;
		return temp;
	}

	public void display() {
		Node currentNode = first;
		System.out.println("First --> Last");
		while (currentNode != null) {
			currentNode.displayNode();
			currentNode = currentNode.next;
		}
	}

	public void insertLast(int data){
		Node currentNode = last;
		/*while (currentNode.next != null) {
			currentNode = currentNode.next;
		}*/
		Node newNode = new Node(data);
		currentNode.next = newNode;
		last = currentNode.next;
	}
	
}
