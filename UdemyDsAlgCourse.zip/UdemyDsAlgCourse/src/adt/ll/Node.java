package adt.ll;

public class Node{
	
	int data;
	Node next = null;
	
	public Node(int data){
		this.data = data;
	}
	
	public void displayNode(){
		System.out.println("{ "+ data +"}");
	}
	
}

