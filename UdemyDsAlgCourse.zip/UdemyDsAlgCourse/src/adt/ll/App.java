package adt.ll;


public class App {

	public static int listLength(Node node) {
		int length = 0;
		while(node != null) {
			length++;
			node = node.next;
		}
		return length;
	}

	public static void main(String args[]) {

		Node nodeA = new Node(4);

		Node nodeB = new Node(3);

		Node nodeC = new Node(7);

		Node nodeD = new Node(8);

		nodeA.next = nodeB;

		nodeB.next = nodeC;

		nodeC.next = nodeD;

		System.out.println(nodeA);

		System.out.println(nodeB);

		System.out.println(nodeC);
		
		System.out.println(listLength(nodeA));
		
		System.out.println(listLength(nodeC));
		
		System.out.println(listLength(nodeB));

	}
}
