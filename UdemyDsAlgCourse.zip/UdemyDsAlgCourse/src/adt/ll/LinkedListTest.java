package adt.ll;

public class LinkedListTest {

	public static void main(String args[]){
		
		LinkedList ll = new LinkedList();
		ll.insertFirst(10);
		ll.insertFirst(20);
		ll.insertFirst(30);
		ll.display();
		ll.deleteFromFirst();
		ll.display();
		ll.insertLast(40);
		ll.display();
		ll.insertLast(50);
		ll.insertFirst(22);
		ll.display();
		ll.insertLast(60);
		ll.insertFirst(33);
		ll.display();
		ll.deleteFromFirst();
		ll.display();
		
	}
}
