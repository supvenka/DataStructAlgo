package adt;

public class TestCounter {

	public static void main(String args[]){
		
		Counter count = new Counter("hello");
		count.increment();
		count.increment();
		
		System.out.println(count.getCurrentValue());
		
		Counter count2 = new Counter("helll");
		System.out.println(count2.getCurrentValue());
		
		System.out.println(count2.toString());
		
	}
}
