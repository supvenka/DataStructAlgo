package adt.algo;

public class BinarySearch {

	public static int search(int[] a, int x) {
		int p = 0;
		int r = a.length - 1;
		int q;
		while (p <= r) {
			q = (p + r) / 2;
			if (a[q] == x) {
				return q;
			}
			if (a[q] > x) {
				r = q - 1;
			}
			if (a[q] < x) {
				p = q + 1;
			}
		}
		return -1;
	}

	public static int recursiveSearch(int[] a, int p, int r, int x) {
		int q;
		if (p > r) {
			return -1;
		} else {
			q = (p + r) / 2;
			if (a[q] == x) {
				return q;
			}
			if (a[q] > x) {
				r = q - 1;
			}
			if (a[q] < x) {
				p = q + 1;
			}
			return recursiveSearch(a, p, r, x);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };

		System.out.println(search(a, 9));

		System.out.println(recursiveSearch(a, 0, a.length - 1, 9));
	}

}
