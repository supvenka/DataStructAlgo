package adt.algo;

public class LinearSearch {

	public static int search(int[] arr, int num) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == num) {
				return i;
			}
		}
		return -1;

	}

	public static int recursiveLinearSearch(int[] arr, int i, int num) {
		int n = arr.length;
		if (i >= n) {
			return -1;
		} else {
			if (arr[i] == num) {
				return i;
			} else {
				return recursiveLinearSearch(arr, i + 1, num);
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 3, 4, 5 };
		System.out.println(search(arr, 6));
		System.out.println(search(arr, 4));
		System.out.println(search(arr, 1));
		System.out.println(recursiveLinearSearch(arr, 0, 1));

	}

}
