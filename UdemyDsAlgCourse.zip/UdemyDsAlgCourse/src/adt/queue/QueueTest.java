package adt.queue;

public class QueueTest {

	public static void main(String args[]){
		
		Queue qu = new Queue(5);
		qu.insert(10);
		qu.insert(12);
		qu.insert(1);
		qu.insert(101);
		System.out.println(qu.remove());
		qu.view();
		qu.insert(102);
		qu.insert(10111);
		qu.view();
		System.out.println(qu.remove());
		qu.view();
		System.out.println(qu.remove());
		qu.view();

		System.out.println(qu.remove());
		qu.view();
		System.out.println(qu.remove());
		qu.view();
		System.out.println(qu.remove());
		qu.view();
		System.out.println(qu.remove());
		qu.view();
	}
}
