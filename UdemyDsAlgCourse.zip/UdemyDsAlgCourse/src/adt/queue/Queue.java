package adt.queue;

public class Queue {

	private int maxSize;
	private long queueArray[];
	private int front;
	private int rear;
	private int numOfItems;

	public Queue(int maxSize) {
		this.maxSize = maxSize;
		this.queueArray = new long[maxSize];
		this.front = 0;
		this.rear = -1;
		this.numOfItems = 0;
	}

	public void insert(long i) {
		if (rear == maxSize - 1) {
			rear = -1;
		}
		rear++;
		queueArray[rear] = i;
		numOfItems++;
	}

	public long remove() {
		long item = queueArray[front];
		front++;
		if (front == maxSize) {
			front = 0;
		}
		numOfItems--;
		return item;
	}
	
	public void view() {
		System.out.print("[");
		for(int i=0;i<queueArray.length;i++){
			System.out.print(queueArray[i]+" ");
		}
		System.out.println("]");
		System.out.println("");
	}

	public boolean isEmpty() {

		return (front == numOfItems);
	}

	public boolean isFull() {
		return (rear == maxSize - 1);
	}

}
