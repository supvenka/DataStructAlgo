package adt.ds;

public class Stack{
	private int maxSize;
	private char stackArray[];
	private int top;

	public Stack(int maxSize) {
		// TODO Auto-generated constructor stub
		this.maxSize = maxSize;
		this.stackArray = new char[maxSize];
		this.top = -1;
	}

	

	public void push(char i) {
		top++;
		if (!isFull()) {
			stackArray[top] = i;
		} else {
			System.out.println("Stack is full,cant really push an item ");
			top--;
		}
	}

	public boolean isFull() {
		// TODO Auto-generated method stub
		return (maxSize == top);
	}

	public char pop() {
		char popped_item = 0 ;
		if (!isEmpty()) {
			int old_top = top;
			top--;
			popped_item = stackArray[old_top];
		}

		return popped_item;
	}

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return (top == -1);
	}

	public char peak() {
		if (!isEmpty())
			return stackArray[top];
		return 0;
	}

}
