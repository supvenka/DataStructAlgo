package adt.ds;

public class StackTest {

	public static void main (String args[]){
		
		Stack_long ts = new Stack_long(5);
		ts.push(10);
		ts.push(20);
		ts.push(30);
		ts.push(12);
		ts.push(40);
		ts.push(60);
		
		System.out.println(ts.peak());
		
		while(!ts.isEmpty()){
			System.out.println(ts.pop());
		}
		
		ts.push(50);
		
		System.out.println(ts.peak());
		ts.pop();
		System.out.println(ts.peak());
		System.out.println(ts.pop());
	}
}
