package adt.ds;

public class ReverseWord {

	public static StringBuffer reverseWord(String word) throws Exception {

		StringBuffer revString = new StringBuffer();

		if (word != null) {
			Stack ds = new Stack(word.length());
			for (int i = 0; i < word.length(); i++) {
				ds.push(word.charAt(i));
				//revString.append("" + word.charAt(i));
			}

			while (!ds.isEmpty()) {
				revString.append("" + ds.pop());
			}
		}

		return revString;

	}

	public static void main(String args[]) throws Exception {

		System.out.println(reverseWord("heeheujeeeeheueeueheheheh  hheheheh"));
	}

}
