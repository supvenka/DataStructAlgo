package adt.ds;

public class Stack_long {
	private int maxSize;
	private long stackArray[];
	private int top;

	public Stack_long(int i) {
		// TODO Auto-generated constructor stub
		this.maxSize = maxSize;
		this.stackArray = new long[maxSize];
		this.top = -1;
	}

	

	public void push(long i) {
		top++;
		if (!isFull()) {
			stackArray[top] = i;
		} else {
			System.out.println("Stack is full,cant really push an item ");
			top--;
		}
	}

	public boolean isFull() {
		// TODO Auto-generated method stub
		return (maxSize == top);
	}

	public long pop() {
		long popped_item = -1;
		if (!isEmpty()) {
			int old_top = top;
			top--;
			popped_item = stackArray[old_top];
		}

		return popped_item;
	}

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return (top == -1);
	}

	public long peak() {
		if (!isEmpty())
			return stackArray[top];
		return -1;
	}

}
